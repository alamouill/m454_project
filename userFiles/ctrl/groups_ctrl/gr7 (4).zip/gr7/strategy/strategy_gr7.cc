#include "strategy_gr7.h"
#include "path_planning_gr7.h"
#include "speed_regulation_gr7.h"
#include "path_regulation_gr7.h"
#include "init_pos_gr7.h"
#include "opp_pos_gr7.h"
#include "odometry_gr7.h"
#include <math.h>
#include <iostream>
#include "useful_gr7.h"

NAMESPACE_INIT(ctrlGr7);

#define capturingDetectionCoeff 1
#define KN	5
#define KD	1.003


/*! \brief intitialize the strategy structure
*
* \return strategy structure initialized
*/
Strategy* init_strategy()
{
	Strategy *strat;

	strat = (Strategy*)malloc(sizeof(Strategy));

	// Coordinates + score of the goal
	//			X									Y								Score
	strat->coord_goal[0][0] = -800;		strat->coord_goal[0][1] = 0;		strat->coord_goal[0][2] = 3;
	strat->coord_goal[1][0] = 250;		strat->coord_goal[1][1] = 1250;		strat->coord_goal[1][2] = 2;
	strat->coord_goal[2][0] = 100;		strat->coord_goal[2][1] = 0;		strat->coord_goal[2][2] = 2;
	strat->coord_goal[3][0] = 250;		strat->coord_goal[3][1] = -1250;	strat->coord_goal[3][2] = 2;
	strat->coord_goal[4][0] = 700;		strat->coord_goal[4][1] = -600;		strat->coord_goal[4][2] = 1;
	strat->coord_goal[5][0] = -400;		strat->coord_goal[5][1] = -600;		strat->coord_goal[5][2] = 1;
	strat->coord_goal[6][0] = -400;		strat->coord_goal[6][1] = 600;		strat->coord_goal[6][2] = 1;
	strat->coord_goal[7][0] = 700;		strat->coord_goal[7][1] = 600;		strat->coord_goal[7][2] = 1;

	return strat;
}


enum { empty, capturing, capturingCheck, capturingCheckOk, gone };

/*! \brief evaluates the oponents behaviour.
*
* \modifies the goals evaluation
*/
void evaluate_Oponent(CtrlStruct *cvs) {
	static double goals[3][4] = {
		//coords, coords, status, taken %
		{ { 0.700 },{ -0.600 },1,100 },
		{ { 0.100 },{ 0 },1,100 },
		{ { -0.400 },{ 0.600 },1,100 }
	};
//	cvs->strat->coord_goal
	static double lastT;
	int NBGOALS = 3;
	int NBOPPS = 1;
	double oppPos[2];
	for (int i = 0; i < NBGOALS; i++) {
		for (int j = 0; j < NBOPPS; j++) {
			oppPos[0] = cvs->opp_pos->x[j];
			oppPos[1] = cvs->opp_pos->y[j];
			if (get_Distance(oppPos, goals[i]) < 0.1) {

				if (goals[i][2] == empty) {
					goals[i][2] = capturing;
					//				goals[i][3] = cvs->inputs->t; //set timer to momentary time
				}
				else if (goals[i][2] == capturingCheck) {
					goals[i][2] = capturingCheckOk;
				}


			}
		}
		//capturingCheck not fulfilled, goal is resetted
		if (goals[i][2] == capturingCheck) {
			goals[i][2] = empty;

			//if some oponent is actually for more than 1scan on the same spot reduce % of goal being there
		}
		else if (goals[i][2] == capturingCheckOk)
		{
			if (goals[i][5] > 0)
			{
				goals[i][3] -= 100 / capturingDetectionCoeff * (cvs->inputs->t - lastT);
			}
			std::cout << "goal %: \n" << goals[i][3];
			goals[i][2] = capturingCheck;
		}
		// set up first capturingCheck after an oponent was registered on goal
		else if (goals[i][2] == capturing) {
			goals[i][2] = capturingCheck;
		}
	}
	lastT = cvs->inputs->t;

}

// Gives a score to every goal and determines the best one to go.
static int determine_goal(CtrlStruct *cvs)
{
	int i = 0;
	int index = 0;
	double distOpp2target, dist2target, score, max = -1;
	for (i = 0; i < 8; i++)
	{
		distOpp2target = 10;//getDistanceFromAtoB(std::pair<int, int>(cvs->opp_pos->x[0] * 1000, cvs->opp_pos->y[0] * 1000), std::pair<int, int>(cvs->strat->coord_goal[i][0], cvs->strat->coord_goal[i][1])) / 1000;
		dist2target = norm_dist(cvs->rob_pos->x - cvs->strat->coord_goal[i][0] / 1000, cvs->rob_pos->y - cvs->strat->coord_goal[i][1]);
		score = KN*cvs->strat->coord_goal[i][2] + distOpp2target - KD*dist2target;
	//	printf("%d \t %f \n", i, distOpp2target);
		if (max == -1)
			max = score;
		if (score > max)
		{
			index = i;
			max = score;
		}
	}
	return index;
}



/*! \brief release the strategy structure (memory released)
*
* \param[out] strat strategy structure to release
*/
void free_strategy(Strategy *strat)
{
	free(strat);
}

/*! \brief startegy during the game
*
* \param[in,out] cvs controller main structure
*/
void main_strategy(CtrlStruct *cvs)
{
	// variables declaration
	Strategy *strat;
	CtrlIn *inputs;

	// variables initialization
	strat = cvs->strat;
	inputs = cvs->inputs;

	//	double goal[2] = { 200,0 };
//	std::pair<int, int> goal[2] = { std::pair<int,int>(-400, -400),
	//	std::pair<int,int>(400,800) };

	std::pair<int, int> momentaryGoal = std::pair<int, int>(strat->coord_goal[strat->index_goal][0],
		strat->coord_goal[strat->index_goal][1]);
	static std::pair<int, int> noGoal(3666, 3666);
	std::pair<int, int> ngoal;
	std::pair<int, int> pos(cvs->rob_pos->x * 1000, cvs->rob_pos->y * 1000);
	static double timer = 0;
	static int goalSwitch = 0;

	determine_goal(cvs);
	switch (strat->main_state)
	{
	case GAME_STATE_START:

		if (cvs->inputs->t > -7)
		{
			//int index_goal = determine_goal(cvs);
		//	std::cout << "goal set: " << index_goal << "\n";
//			std::pair<int, int> goal = std::pair<int, int>(800, 800);
//			set_goal(cvs->path, pos, goal);
			strat->main_state = GAME_STATE_SET_NEW_GOAL;


			timer = cvs->inputs->t;
		}
		path_planning(cvs);
		follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
		std::cout << "intermediate goal: " << cvs->path->nextGoal[0] << " " << cvs->path->nextGoal[1] << "\n";
		break;

	case GAME_STATE_DRIVE:

		// todo: check for intermediate checkpoints reached.
		//	std::cout << "_strat " << cvs->path->nextGoal[0] << "\t" << cvs->path->nextGoal[1]<<"\n";
	//	int goal[2] = { strat->coord_goal[strat->index_goal][0],
	//					strat->coord_goal[strat->index_goal][1] };
//		std::cout << "goal: " << momentaryGoal.first << " pos " << pos.first << "\n";
//		std::cout << "2goal: " << momentaryGoal.second << " 2pos " << pos.second << "\n";
		std::cout << "distance: " << get_Distance(momentaryGoal, pos) << "\n";
		if (get_Distance(momentaryGoal, pos) < 80) {
			std::cout << "_ strat CA MARCHE\n";
			set_goal(cvs->path, pos, noGoal);		            //                       doesn't work
			cvs->strat->main_state = GAME_STATE_Capture; // wait 3sec

			timer = cvs->inputs->t;
			std::cout << "timer start: " << (cvs->inputs->t - timer) << "\n";
			break;
		}
		update_path_planning(cvs);
		path_planning(cvs);
		follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
		break;

	case GAME_STATE_Capture:

		if (cvs->inputs->t - timer > 1) {														//todo change to exact secs
			std::cout << "timer over 1s\n";
			cvs->strat->main_state = GAME_STATE_SET_NEW_GOAL; // set new goal
		}
		else {
			std::cout << "time elapsed: " << (cvs->inputs->t - timer) << "\n";
		}

		path_planning(cvs);
		follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);

		break;

	case GAME_STATE_SET_NEW_GOAL:

		std::cout << "new goal should be set" << (cvs->inputs->t - timer) << "\n";

		strat->index_goal = determine_goal(cvs);
		ngoal = std::pair<int, int>(strat->coord_goal[strat->index_goal][0], 
													   strat->coord_goal[strat->index_goal][1]);
		set_goal(cvs->path, pos, ngoal);

		path_planning(cvs);
		follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
		cvs->strat->main_state = GAME_STATE_DRIVE;
		printf("new goal set\n");
		break;

	case GAME_STATE_E:
		speed_regulation(cvs, 0.0, 0.0);
		break;

	default:
		printf("Error: unknown strategy main state: %d !\n", strat->main_state);
		exit(EXIT_FAILURE);
	}


}

NAMESPACE_CLOSE();
