#include "strategy_gr7.h"
#include "path_planning_gr7.h"
#include "speed_regulation_gr7.h"
#include "path_regulation_gr7.h"
#include "init_pos_gr7.h"
#include "opp_pos_gr7.h"
#include "odometry_gr7.h"
#include <math.h>
#include <iostream>
#include "useful_gr7.h"

NAMESPACE_INIT(ctrlGr7);

#define capturingDetectionCoeff 1


/*! \brief intitialize the strategy structure
 * 
 * \return strategy structure initialized
 */
Strategy* init_strategy()
{
	Strategy *strat;

	strat = (Strategy*) malloc(sizeof(Strategy));

	return strat;
}


enum { empty, capturing, capturingCheck, capturingCheckOk, gone };
/*! \brief evaluates the oponents behaviour.
*
* \modifies the goals evaluation
*/
void evaluate_Oponent(CtrlStruct *cvs) {
	static double goals[3][4] = {
		//coords, coords, status, taken %
		{ { 0.700 },{ -0.600 },1,100 },
		{ { 0.100 },{ 0 },1,100 },
		{ { -0.400 },{ 0.600 },1,100 }
	};
	static double lastT;
	int NBGOALS = 3;
	int NBOPPS = 1;
	double oppPos[2];
	for (int i = 0; i < NBGOALS; i++) {
		for (int j = 0; j < NBOPPS; j++) {
			oppPos[0] = *cvs->opp_pos->x;
			oppPos[1] = *cvs->opp_pos->y;
			if (get_Distance(oppPos, goals[i]) < 0.1) {

				if (goals[i][2] == empty) {
					goals[i][2] = capturing;
					//				goals[i][3] = cvs->inputs->t; //set timer to momentary time
				}
				else if (goals[i][2] == capturingCheck) {
					goals[i][2] = capturingCheckOk;
				}


			}
		}
		//capturingCheck not fulfilled, goal is resetted
		if (goals[i][2] == capturingCheck) {
			goals[i][2] = empty;

			//if some oponent is actually for more than 1scan on the same spot reduce % of goal being there
		}
		else if (goals[i][2] == capturingCheckOk)
		{
			goals[i][3] -= 100 / capturingDetectionCoeff * (cvs->inputs->t - lastT);
			std::cout << "goal %: \n" << goals[i][3];
			goals[i][2] = capturingCheck;
		}
		// set up first capturingCheck after an oponent was registered on goal
		else if (goals[i][2] == capturing) {
			goals[i][2] = capturingCheck;
		}
	}
	lastT = cvs->inputs->t;

}




/*! \brief release the strategy structure (memory released)
 * 
 * \param[out] strat strategy structure to release
 */
void free_strategy(Strategy *strat)
{
	free(strat);
}

/*! \brief startegy during the game
 * 
 * \param[in,out] cvs controller main structure
 */
void main_strategy(CtrlStruct *cvs)
{
	// variables declaration
	Strategy *strat;
	CtrlIn *inputs;

	// variables initialization
	strat  = cvs->strat;
	inputs = cvs->inputs;

//	double goal[2] = { 200,0 };
	std::pair<int, int> goal[2] = { std::pair<int,int>(-400, -400),
									std::pair<int,int>(400,800) };
	std::pair<int, int> noGoal(3666, 3666);
	std::pair<int, int> goal2(-400, -400);
	std::pair<int,int> pos( cvs->rob_pos->x * 1000,cvs->rob_pos->y * 1000 );
	static double timer = 0;
	static int goalSwitch = 0;


	switch (strat->main_state)
	{
		case GAME_STATE_START:
	
			if (cvs->inputs->t > -7)
			{
				set_goal(cvs->path,  pos, goal[goalSwitch]);
				strat->main_state = GAME_STATE_DRIVE;
				timer = cvs->inputs->t;
			}
			path_planning(cvs);
			follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
			break;

		case GAME_STATE_DRIVE:
			
			// todo: check for intermediate checkpoints reached.
		//	std::cout << "_strat " << cvs->path->nextGoal[0] << "\t" << cvs->path->nextGoal[1]<<"\n";
			if (get_Distance(goal[goalSwitch], pos) < 50) {
				std::cout << "_ strat CA MARCHE\n";
				set_goal(cvs->path, pos, noGoal);		            //                       doesn't work
				cvs->strat->main_state = GAME_STATE_C; // wait 3sec
								
				timer = cvs->inputs->t;
				std::cout << "timer start: " << (cvs->inputs->t - timer) << "\n";
				break;
			}
			update_path_planning(cvs);
			path_planning(cvs);
			follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
			break;

		case GAME_STATE_C:

			if (cvs->inputs->t - timer > 1) {														//todo change to exact secs
				std::cout << "timer over 1s\n";
				cvs->strat->main_state = GAME_STATE_D; // set new goal
			}
			else {
				std::cout << "time elapsed: " << (cvs->inputs->t - timer) << "\n";
			}
		
			path_planning(cvs);
			follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
			
			break;

		case GAME_STATE_D:
			
			std::cout << "new goal should be set" << (cvs->inputs->t - timer) << "\n";
			goalSwitch = !goalSwitch;
			//todo: find new goal, here the respective other one of the goal table is taken.
			set_goal(cvs->path, pos, goal[goalSwitch]);
			path_planning(cvs);
			follow_path(cvs, cvs->path->theta, cvs->path->linspeed, cvs->rob_pos->theta);
			cvs->strat->main_state = GAME_STATE_DRIVE;
			printf("new goal set\n");
			break;

		case GAME_STATE_E:
			speed_regulation(cvs, 0.0, 0.0);
			break;

		default:
			printf("Error: unknown strategy main state: %d !\n", strat->main_state);
			exit(EXIT_FAILURE);
	}


}

NAMESPACE_CLOSE();
